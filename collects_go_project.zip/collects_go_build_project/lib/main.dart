import 'package:flutter/material.dart';

void main() => runApp(const CollectsGoApp());

class CollectsGoApp extends StatelessWidget {
  const CollectsGoApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: "Collect's Go",
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFB8FF42)), useMaterial3: true),
    home: const HomeScreen(),
  );
}

class Fruit { final String name, rarity, emoji; final int coins; const Fruit(this.name,this.rarity,this.emoji,this.coins); }
const fruits = [Fruit('Flame Fruit','Common','🔥',10), Fruit('Leaf Fruit','Rare','🍃',25), Fruit('Storm Fruit','Epic','⚡',60), Fruit('Dragon Fruit','Legendary','🐉',150), Fruit('Galaxy Fruit','Mythic','🌌',300)];

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
  int coins=120, level=1, selected=0; final List<Fruit> bag=[]; String username='Player';
  @override Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF10151C),
    body: SafeArea(child: Column(children:[
      Padding(padding: const EdgeInsets.all(18), child: Row(children:[const CircleAvatar(backgroundColor: Color(0xFFB8FF42), child: Text('🍏',style: TextStyle(fontSize:24))), const SizedBox(width:10), const Expanded(child: Text("COLLECT'S GO",style:TextStyle(color:Colors.white,fontWeight:FontWeight.w900,fontSize:22))), Text('🪙 $coins',style:const TextStyle(color:Color(0xFFB8FF42),fontWeight:FontWeight.bold))])),
      Expanded(child: IndexedStack(index:selected,children:[
        ListView(padding:const EdgeInsets.all(18),children:[Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(color:const Color(0xFF242D37),borderRadius:BorderRadius.circular(24)),child:Column(children:[const Text('🍎',style:TextStyle(fontSize:90)),const Text('HUNT RARE FRUITS',style:TextStyle(color:Color(0xFFB8FF42),fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text('$username  •  Level $level',style:const TextStyle(color:Colors.white70)),const SizedBox(height:18),FilledButton(onPressed:collect,child:const Text('Collect a nearby fruit'))])),const SizedBox(height:18),const Text('FRUIT DISCOVERIES',style:TextStyle(color:Colors.white,fontWeight:FontWeight.bold)),const SizedBox(height:8),...fruits.map((f)=>Card(color:const Color(0xFF242D37),child:ListTile(leading:Text(f.emoji,style:const TextStyle(fontSize:30)),title:Text(f.name,style:const TextStyle(color:Colors.white)),subtitle:Text(f.rarity,style:const TextStyle(color:Colors.white60)),trailing:Text('+${f.coins} 🪙',style:const TextStyle(color:Color(0xFFB8FF42))))))]),
        ListView(padding:const EdgeInsets.all(18),children:[const Text('YOUR INVENTORY',style:TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:12),if(bag.isEmpty) const Text('No fruits yet. Start a hunt!',style:TextStyle(color:Colors.white70)) else ...bag.map((f)=>ListTile(leading:Text(f.emoji,style:const TextStyle(fontSize:28)),title:Text(f.name,style:const TextStyle(color:Colors.white)),subtitle:Text(f.rarity,style:const TextStyle(color:Colors.white60))))]),
        ListView(padding:const EdgeInsets.all(18),children:[const Text('HUNT MAP',style:TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:12),Container(height:230,decoration:BoxDecoration(color:const Color(0xFF242D37),borderRadius:BorderRadius.circular(20)),child:const Center(child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(Icons.map,color:Color(0xFFB8FF42),size:70),Text('Map preview only',style:TextStyle(color:Colors.white,fontSize:18)),Text('Live GPS and AR are not connected',style:TextStyle(color:Colors.white60))]))),const SizedBox(height:18),const Text('Leaderboard',style:TextStyle(color:Colors.white,fontSize:20,fontWeight:FontWeight.bold)),const ListTile(leading:Text('🥇'),title:Text('FruitMaster',style:TextStyle(color:Colors.white)),trailing:Text('12 Legendary',style:TextStyle(color:Colors.white70))),ListTile(leading:const Text('⭐'),title:Text(username,style:const TextStyle(color:Colors.white)),trailing:const Text('Your rank: Demo',style:TextStyle(color:Colors.white70)))]),
      ])),
      NavigationBar(backgroundColor:const Color(0xFF1B222B),indicatorColor:const Color(0xFFB8FF42),selectedIndex:selected,onDestinationSelected:(v)=>setState(()=>selected=v),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),NavigationDestination(icon:Icon(Icons.inventory_2_outlined),label:'Bag'),NavigationDestination(icon:Icon(Icons.map_outlined),label:'Map')]),
    ])));
  void collect(){final f=fruits[DateTime.now().millisecondsSinceEpoch%fruits.length];setState(()=>{bag.add(f),coins+=f.coins,level=1+bag.length~/3});ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Found ${f.emoji} ${f.name}! +${f.coins} coins')));}
}
